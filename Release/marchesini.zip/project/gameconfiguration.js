var numberOfCube=1;
var cubePositions = [];
var cubeColors = [];
var cubeCollision = [];
var GameState = 0;  // 0 Init
                    // 1 Running
                    // 2 Win
                    // 3 Lose