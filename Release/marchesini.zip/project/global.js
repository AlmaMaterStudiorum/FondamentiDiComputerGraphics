var speed = 0;
var ArrowRotation = 0;

var sphereDirection = [-1,0,-0.5];

var sphereCurrentPosition = SphereInitPosition;

var startgame ;
// Variables linked to button on/off functionality
var  toggle_frustum_on_off = false;